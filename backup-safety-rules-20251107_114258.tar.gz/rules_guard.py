#!/usr/bin/env python3
def main():
    print("[HINT] Thresholds are env-configurable; blender/threshold edits must touch SSOT docs (AGENTS.md / RULES).")


if __name__ == "__main__":
    main()
