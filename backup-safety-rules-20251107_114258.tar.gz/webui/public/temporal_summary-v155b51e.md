# Temporal Summary

_No data found._
