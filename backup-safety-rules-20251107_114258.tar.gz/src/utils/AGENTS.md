# AGENTS.md - src/utils Directory

## Directory Purpose

The `src/utils/` directory contains utils components for the Gematria analysis pipeline.

## Key Components

<!-- Add key components and their purposes here -->

## API Contracts

<!-- Add function/class signatures and contracts here -->

## Testing Strategy

<!-- Add testing approach and coverage requirements here -->

## Development Guidelines

<!-- Add coding standards and patterns specific to this directory here -->

## Related ADRs

| Component/Function | Related ADRs |
|-------------------|--------------|
<!-- Add ADR references here -->
