"""Infrastructure helpers for IO and environment interactions."""

from .filesystem import read_text

__all__ = ["read_text"]
