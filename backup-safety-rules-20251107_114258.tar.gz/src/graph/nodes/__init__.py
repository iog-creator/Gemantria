"""Node helpers for the bootstrap graph."""

from .base import GraphNode

__all__ = ["GraphNode"]
